for (var i = 0; i < 6; i++) {
    console.log(i);
}