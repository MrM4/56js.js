

//先引入 后使用 

let fs = require("fs")


/*async function readFile () {
   let a = await new Promise((res,rej)=>{
        fs.readFile("./01.txt",function (err,data) {
            var data = data.toString()
            res(data)//01.txt里面的 路径 => ./02.txt
        })
   })

   let b = await new Promise((res,rej)=>{
        fs.readFile( a ,function (err,data) {
            var data = data.toString()
            res(data) //02.txt里面的 路径 => ./03.txt
        })
   })
   let c = await new Promise((res,rej)=>{
        fs.readFile( b ,function (err,data) {
            var data = data.toString()
            res(data) //03.txt里面的 路径 => ./04.txt
        })
   })
   let d = await new Promise((res,rej)=>{
        fs.readFile( c ,function (err,data) {
            var data = data.toString()
            console.log(data)
            res(data) //04.txt里面的 路径 => find !!!
        })
   })
}

readFile()*/

/* fs.appendFile("./05.txt", "来吧,我给你添加点内容02", (err) => {
    console.log(err)
})
 */