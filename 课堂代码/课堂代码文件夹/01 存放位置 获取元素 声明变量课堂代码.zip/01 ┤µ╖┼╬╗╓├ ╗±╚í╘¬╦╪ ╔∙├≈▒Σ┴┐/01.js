window.onload = function () {
    //所有的代码放进来
}