{

​    // Place your snippets for html here. Each snippet is defined under a snippet name and has a prefix, body and 

​    // description. The prefix is what is used to trigger the snippet and the body will be expanded and inserted. Possible variables are:

​    // $1, $2 for tab stops, $0 for the final cursor position, and ${1:label}, ${2:another} for placeholders. Placeholders with the 

​    // same ids are connected.

​    // Example:

​    // "Print to console": {

​    //  "prefix": "log",

​    //  "body": [

​    //      "console.log('$1');",

​    //      "$2"

​    //  ],

​    //  "description": "Log output to console"

​    // }

​    "html模板":{ "prefix": "hh",

​         "body": [ "<!DOCTYPE html>", 

​            "<html>",

​             "<head>",

​              "\t<meta charset=\"UTF-8\">", 

​              "\t<title>52js-冬日暖阳</title>",

​              "\t<link rel=\"stylesheet/less\" type=\"text/css\" href=\"css/index.less\">",

​              "\t<script src=\"https://cdn.bootcss.com/less.js/3.9.0/less.min.js \"></script>",

​              "\t<style>",

​              "\t\tbody,h1,h2,h3,h4,h5,h5,p,div{margin:0;padding:0;}",

​               "\t\tli{list-style:none;}", 

​               "\t\ta{text-decoration: none;}",

​               "\t\theader{\n\t\t\tmargin:20px auto;\n\t\t\twidth:500px;\n\t\t\theight:280px;\n\t\t\tbackground-color:#999;\n\t\t}", 

​               "\t</style>", 

​                "</head>",

​                 "<body>", 

​                "\t<header id=\"wrap\">$1</header>",

​                "\t<script>\n\t\t$2\n\t</script>", 

​                "</body>", 

​                "</html>" ]}

}