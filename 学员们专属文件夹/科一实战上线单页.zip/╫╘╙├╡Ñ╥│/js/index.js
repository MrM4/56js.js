/* 多层商品展示块 */
let aTap = document.querySelectorAll(".atop p");
let aRt = document.getElementsByClassName("aright");
/* 侧边导航栏 */
let aP = document.querySelectorAll("#bat p")
let aUl = document.querySelectorAll("#bat ul")
let aList = document.getElementsByClassName(".show")
let aLst = document.querySelectorAll("#bat ul li")


let lec = aLst.length
let len = aUl.length 
let index = 0
// console.log(aLst);

// <!-- 首页轮播图 -->
let aImg = document.querySelectorAll("#img li"),
aList1 = document.querySelectorAll("#list li"),
aBtn = document.getElementsByClassName("btn"),
oban = document.getElementById("banner1"),
len1 = aList1.length,
n = 0,
timer = null;
//主菜单模块
for(let i = 0; i<len; i++){
    aP[i].lat = true;

      aP[i].onclick = function(){
        if(aP[i].lat){
            aUl[i].className = "show";    
        }else{
            aUl[i].className = "";
        }
            aP[i].lat = !aP[i].lat;
            
        for(let j=0;j<len;j++){
        if(j !==i && aP[j].lat === false){ 
            aUl[j].className = ""; 
            aP[j].lat = true;  
     } } } }
// 子菜单模块
for(let k=0;k<lec;k++){
    aLst[k].kat = true;
        aLst[k].onclick = function(){
        if(aLst[k].kat){
                aLst[k].className = "active";
        }else{
            aLst[k].className = "" ;
        }
        aLst[k].kat = !aLst[k].kat;
        for(let m=0;m<lec;m++){
        if(m !== k && aLst[m].kat===false){
            aLst[m].className = "" ;
            aLst[m].kat = true;
        } } 
        
        } } 
/* 轮播图控制块 */
/* index1 = 0 */;
   //下一张切换按钮
   autoplay();
    function autoplay(){
        timer = setInterval(function(){
        n++;
        index = n % len1;
        change(index);
        },3000)}

    oban.onmouseover = function(){
        clearInterval(timer);
        }
    oban.onmouseout = function(){
        autoplay();
        }
    for(let i = 0;i < len1;i++){
        aList1[i].onclick = function(){
            index = i;
            change(index);
         } 
        }
        
        aBtn[0].onclick = function(){
            index--;
            if(index < 0){
                index = len1 - 1;
                }
                change(index);
            }
        aBtn[1].onclick = function(){
            index++;
            if(index > len1-1){
                index=0;
                }
                change(index);
            }
    function change(index){
        for(let i = 0;i < len1;i++){
            aImg[i].classList.remove("show1");
            aList1[i].classList.remove("on");
            }
            aImg[index].classList.add("show1");
            aList1[index].classList.add("on");
        }

    /* 多层商品展示区块 */
    aTap[0].onclick = function(){
        aRt[0].classList.add("atc");
        aRt[1].classList.remove("atc");
        aRt[2].classList.remove("atc");   
    } 
    aTap[1].onclick = function(){
        aRt[1].classList.add("atc");
        aRt[0].classList.remove("atc");
        aRt[2].classList.remove("atc");    
    } 
    aTap[2].onclick = function(){
        aRt[2].classList.add("atc");
        aRt[1].classList.remove("atc");
        aRt[0].classList.remove("atc");   
    } 