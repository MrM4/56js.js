let Koa = require("koa")
let cors = require("@koa/cors")

let app = new Koa()

app.use(cors()) //允许跨域

app.use(async data => {
    data.body = "<p style='color:skyblue'>我是后台返回数据雀雀</p>"
})

app.listen(8000)

console.log("程序已经启动,运行在8000端口");